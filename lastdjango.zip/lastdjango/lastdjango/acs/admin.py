from django.contrib import admin
from .models import ShareAccesses, Accesses, Services


class AccessesAdmin(admin.ModelAdmin):
    list_display = ('id', 'owner', 'title', 'service', 'comment')


class ServicesAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'owner')


class ShareAccessesAdmin(admin.ModelAdmin):
    list_display = ('id', 'owner', 'shares', 'title', 'service', 'comment')


admin.site.register(Services, ServicesAdmin)
admin.site.register(Accesses, AccessesAdmin)
admin.site.register(ShareAccesses, ShareAccessesAdmin)

