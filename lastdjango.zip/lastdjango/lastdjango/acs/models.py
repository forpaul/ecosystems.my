from django.db import models


class Services(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    owner = models.CharField(max_length=30)

    def __str__(self):
        return self.name

    class Meta:
        app_label = 'acs'


class Accesses(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50)
    service = models.ForeignKey(Services, on_delete=models.SET_NULL, null=True)
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=100)
    comment = models.CharField(max_length=150)
    owner = models.CharField(max_length=30)

    def __str__(self):
        return self.title


class ShareAccesses(models.Model):
    id = models.AutoField(primary_key=True)
    id_accesses = models.ForeignKey(Accesses, on_delete=models.SET_NULL, null=True)
    title = models.CharField(max_length=50)
    service = models.CharField(max_length=100)
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=100)
    comment = models.CharField(max_length=150)
    owner = models.CharField(max_length=30)
    shares = models.ManyToManyField(Accesses)

    def __str__(self):
        return self.shares

