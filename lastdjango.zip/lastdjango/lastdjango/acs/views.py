from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.shortcuts import render
from .models import Accesses, ShareAccesses, Services
from .forms import AccessesForm, RegForm, LogForm, ServiceForm


def index(request):
    form = AccessesForm(user=request.user)
    UserAccesses = Accesses.objects.filter(owner=request.session['username'])

    return render(request, "index.html", {'AddAccess': form, 'AddService': ServiceForm, 'UserAccesses': UserAccesses})


def regist_page(request):
    return render(request, "regist_page.html", {'registForm': RegForm})


def addService(request):
    frm = ServiceForm(data=request.POST)
    if frm.is_valid():
        name = frm.cleaned_data['name']
        tmp_query = Services.objects.create(name=name, owner=request.session['username'])
        tmp_query.save()

        return HttpResponseRedirect('/')
    else:
        return render(request, "index.html", {'AddAccess': AccessesForm, 'AddService': frm})


def addAccess(request):
    frm = AccessesForm(data=request.POST)
    if frm.is_valid():
        title = frm.cleaned_data['title']
        service = frm.cleaned_data['service']
        username = frm.cleaned_data['username']
        password = frm.cleaned_data['password']
        comment = frm.cleaned_data['comment']
        tmp_query = Accesses.objects.create(title=title, service=service, username=username, password=password,
                                            comment=comment, owner=request.session['username'])
        tmp_query.save()

        return HttpResponseRedirect('/')
    else:
        return render(request, "index.html", {'AddAccess': AccessesForm, 'AddService': frm})


def regist(request):
    if request.method == 'POST':
        frm = RegForm(data=request.POST)
        if frm.is_valid():
            username = frm.cleaned_data['username']
            password = frm.cleaned_data['password']

            user = User.objects.create_user(username=username, password=password)
            user.save()
            return HttpResponseRedirect('/')
        else:
            return render(request, "regist_page.html", {'registForm': frm})


def login_page(request):
    if 'username' not in request.session:
        return render(request, "login.html", {'logForm': LogForm})
    else:
        return index(request)


def auth(request):
    username = request.POST.get('username')
    password = request.POST.get('password')

    user = authenticate(username=username, password=password)

    if user is not None:
        if user.is_active:
            login(request, user)
            request.session['username'] = username
            print("User is valid, active and authenticated")
        else:
            print("The password is valid, but the account has been disabled!")
    else:
        print("The username and password were incorrect.")
    return HttpResponseRedirect("/")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect("/")
