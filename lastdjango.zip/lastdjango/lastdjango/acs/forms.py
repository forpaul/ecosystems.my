from django.contrib.auth.models import User
from django.core.exceptions import ValidationError
from .models import Accesses, Services, ShareAccesses
from django import forms


class AccessesForm(forms.ModelForm):
    class Meta:
        model = Accesses
        fields = [
            'title',
            'service',
            'username',
            'password',
            'comment'
        ]

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        if user:
            self.fields['service'].queryset = Services.objects.filter(owner=user)


class ServiceForm(forms.ModelForm):
    class Meta:
        model = Services
        fields = [
            'name'
        ]

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if Services.objects.filter(name=name).exists():
            raise ValidationError("Service already exist")
        else:
            return name


class RegForm(forms.ModelForm):
    class Meta:
        model = User
        fields = [
            'username',
            'password'
        ]

    def clean_username(self):
        username = self.cleaned_data.get('username')
        if User.objects.filter(username=username).exists():
            raise ValidationError("Username already exist")
        else:
            return username


class LogForm(forms.Form):
    username = forms.CharField(min_length=4, max_length=30)
    password = forms.CharField(max_length=30, widget=forms.PasswordInput)
