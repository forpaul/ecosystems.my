from django.contrib import admin
from .models import Accesses, Services


# Register your models here.
class AccessesAdmin(admin.ModelAdmin):
    list_display = ('id', 'owner', 'title', 'service', 'comment')


class ServicesAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'owner')


admin.site.register(Services, ServicesAdmin)
admin.site.register(Accesses, AccessesAdmin)
