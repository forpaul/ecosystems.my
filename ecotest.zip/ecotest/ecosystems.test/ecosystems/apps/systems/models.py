from django.db import models


# Create your models here.


class Accesses(models.Model):
    id = models.AutoField(primary_key=True)
    title = models.CharField(max_length=50)
    service = models.CharField(max_length=50, null=True)
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=200)
    comment = models.CharField(max_length=150, blank=True, null=True)
    owner = models.CharField(max_length=30)

    def __str__(self):
        return self.username


class Services(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=30)
    owner = models.CharField(max_length=30)

    def __str__(self):
        return self.name
