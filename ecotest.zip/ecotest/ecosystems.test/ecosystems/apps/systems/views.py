from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.shortcuts import render
from django.contrib.auth import logout
from django.contrib.auth import authenticate, login
from .forms import AccessesForm, ServicesForm, RegistForm
from .models import Accesses, Services


def registUser(request):
    if 'username' not in request.session:
        return render(request, "registration.html", {'registForm': RegistForm})
    else:
        allAccesses = Accesses.objects.filter(owner=request.session['username'])
        allServices = Services.objects.filter(owner=request.session['username'])
        return render(request, "index.html",
                      {'accessForm': AccessesForm, 'Accesses': allAccesses, 'sForm': ServicesForm,
                       'Services': allServices})


def registUserAction(request):
    if request.method == 'POST':
        frm = RegistForm(data=request.POST)
        if frm.is_valid():
            username = frm.cleaned_data['username']
            password = frm.cleaned_data['password']

            user = User.objects.create_user(username=username, password=password)
            user.save()
            return HttpResponseRedirect('/')
        else:
            return render(request, "registration.html", {'registForm': frm})


def log_in(request):
    if 'username' not in request.session:
        return render(request, "login.html", {})
    else:
        allAccesses = Accesses.objects.filter(owner=request.session['username'])
        allServices = Services.objects.filter(owner=request.session['username'])
        return render(request, "index.html",
                      {'accessForm': AccessesForm, 'Accesses': allAccesses, 'sForm': ServicesForm,
                       'Services': allServices})


def addAccess(request):
    if request.method == 'POST':
        frm = AccessesForm(data=request.POST)
        if frm.is_valid():
            title = frm.cleaned_data['title']
            service = frm.cleaned_data['service']
            username = frm.cleaned_data['username']
            password = frm.cleaned_data['password']
            comment = frm.cleaned_data['comment']

            Accesses.objects.create(title=title, service=service, username=username, password=password, comment=comment,
                                    owner=request.session['username'])
            return HttpResponseRedirect('/')
        else:
            return render(request, 'index.html', {'accessForm': frm})


def changeAccess(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        title = request.POST.get('title')
        service = request.POST.get('serviceForModal')
        username = request.POST.get('username')
        password = request.POST.get('password')
        comment = request.POST.get('comment')
        owner = request.POST.get('owner')

        service_s = Services.objects.get(id=service)

        if not service:
            Accesses.objects.filter(id=id).update(title=title, username=username, password=password,
                                                  comment=comment,
                                                  owner=owner)
        else:
            Accesses.objects.filter(id=id).update(title=title, service=service_s.name, username=username, password=password,
                                                  comment=comment,
                                                  owner=owner)
        return HttpResponseRedirect("/")


def share(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        service = request.POST.get('service')
        username = request.POST.get('username')
        password = request.POST.get('password')
        comment = request.POST.get('comment')
        owner = request.POST.get('usernameForModal')

        user_s = User.objects.get(id=owner)
        Accesses.objects.create(title=title, service=service, username=username,
                                password=password, comment=comment, owner=user_s.username)
        return HttpResponseRedirect("/")


def deleteAccess(request):
    if request.method == 'POST':
        id = request.POST.get('id')
    Accesses.objects.filter(id=id).delete()
    return HttpResponseRedirect("/")


def Sort(request):
    if request.POST.get('sort'):
        name = request.POST.get('name')
        SortAccesses = Accesses.objects.filter(owner=request.session['username'], service=name)
        allServices = Services.objects.filter(owner=request.session['username'])
        return render(request, "index.html",
                      {'accessForm': AccessesForm, 'Accesses': SortAccesses, 'sForm': ServicesForm,
                       'Services': allServices})
    else:
        allAccesses = Accesses.objects.filter(owner=request.session['username'])
        allServices = Services.objects.filter(owner=request.session['username'])
        return render(request, "index.html",
                      {'accessForm': AccessesForm, 'Accesses': allAccesses, 'sForm': ServicesForm,
                       'Services': allServices})


def addService(request):
    if request.method == 'POST':
        frm = ServicesForm(data=request.POST)
        if frm.is_valid():
            name = frm.cleaned_data['name']

            Services.objects.create(name=name, owner=request.session['username'])

            return HttpResponseRedirect('/')
        else:
            return render(request, 'index.html', {'serviceForm': frm})


def deleteService(request):
    if request.method == 'POST':
        id = request.POST.get('id')
        Services.objects.filter(id=id).delete()
        return HttpResponseRedirect('/')


def changeService(request):
    if request.method == 'POST':
        form = ServicesForm()
        if form.is_valid():
            id = request.POST.get('id')
            name = request.POST.get('name')
            owner = request.POST.get('owner')

            Services.objects.filter(id=id).update(name=name, owner=owner)
        return HttpResponseRedirect("/")


def auth(request):
    username = request.POST.get('username')
    password = request.POST.get('password')

    user = authenticate(username=username, password=password)

    if user is not None:
        if user.is_active:
            login(request, user)
            request.session['username'] = username
            print("User is valid, active and authenticated")
        else:
            print("The password is valid, but the account has been disabled!")
    else:
        print("The username and password were incorrect.")
    return HttpResponseRedirect("/")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect("/")
