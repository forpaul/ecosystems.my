function spoiler(n) {
    element = document.getElementById(n);
    if (element.style.display == 'none')
        element.style.display = 'block'
    else element.style.display = 'none';
}

function showHide(n) {
    var encr = document.getElementById(n);
    if (encr.type == 'password')
        encr.type = 'text'
    else encr.type = 'password';

}
function showForm() {
    var plus = document.getElementById('formDiv');
    if (plus.style.visibility == 'hidden')
        plus.style.visibility = 'visible'
    else plus.style.visibility = 'hidden';
}
function showServ(){
    var plus = document.getElementById('formServ');
    if (plus.style.visibility == 'hidden')
        plus.style.visibility = 'visible'
    else plus.style.visibility = 'hidden';
}

function copyPass(n){
    var password_to = document.getElementById(n);
        password_to.focus();
        password_to.select();
        try {
            var successful = document.execCommand('copy');
            var msg = successful ? 'successful' : 'unsuccessful';
            console.log('Copying text command was ' + msg);
        }
        catch (err) {
            console.log('Oops, unable to copy');
        }
}
function copyLog(n){
    var login_to = document.getElementById(n);
        login_to.focus();
        login_to.select();
        try {
            var successful = document.execCommand('copy');
            var msg = successful ? 'successful' : 'unsuccessful';
            console.log('Copying text command was ' + msg);
        }
        catch (err) {
            console.log('Oops, unable to copy');
        }
}