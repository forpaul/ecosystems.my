from django import forms
from django.http import HttpResponseRedirect

from .models import Services
from django.contrib.auth.models import User


class RegistForm(forms.Form):
    username = forms.CharField(max_length=50, min_length=4)
    password = forms.CharField(max_length=200, min_length=6, widget=forms.PasswordInput)


class AccessesForm(forms.Form):
    title = forms.CharField(max_length=50, min_length=10)
    service = forms.ModelChoiceField(queryset=Services.objects.all())
    serviceForModal = forms.ModelChoiceField(queryset=Services.objects.all(),
                                             required=False)
    username = forms.CharField(max_length=50)
    usernameForModal = forms.ModelChoiceField(queryset=User.objects.all(), required=False)
    password = forms.CharField(min_length=6, max_length=200, widget=forms.PasswordInput)
    comment = forms.CharField(max_length=150, min_length=10, required=False)

    def clean_title(self):
        # Одно поле
        title = self.cleaned_data.get('title')
        title.replace(' ', '')
        return title

    def clean_comment(self):
        # Одно поле
        comment = self.cleaned_data.get('comment')
        comment.replace(' ', '')
        return comment


class ServicesForm(forms.Form):
    name = forms.CharField(max_length=50, min_length=1)

    def clean_name(self):
        name = self.cleaned_data.get('name')
        name.replace(' ', '')
        return name
