from django.apps import AppConfig


class SystemsConfig(AppConfig):
    name = 'ecosystems.apps.systems'
